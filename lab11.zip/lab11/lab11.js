//Name: Buddie Powell
// Section: Mon/wens hybrid 10:30am to 12:100pm
//date: 5/12/26

// const variables
const express = require("express");
const path = require("path");
const app = express();
const PORT = 3000;

// root page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "lab11.html"));
});
// this first endpoint will display Hello World
app.get("/helloworld", (req, res) => {
  res.send("<h1>Hello World</h1>");
});

// this second endpoint will display a json object with videogames
const videoGames = [
  {
    id: 1,
    title: "Zelda",
    genre: "Action-Adventure",
    platform: "Switch",
    releaseYear: 2023,
  },
  {
    id: 2,
    title: "Minecraft",
    genre: "Sandbox",
    platform: "Multi",
    releaseYear: 2011,
  },
  {
    id: 3,
    title: "Elden Ring",
    genre: "Action RPG",
    platform: "PC/PS/Xbox",
    releaseYear: 2022,
  },
];

// gets the video game data and outputs it to the local host
app.get("/data", (req, res) => {
  res.json(videoGames);
});

// this third endpoint displays the main page content
app.get("/index", (req, res) => {
  res.sendFile(path.join(__dirname, "lab11.html"));
});

app.listen(PORT, () => {
  console.log(`Server running: http://localhost:${PORT}`);
});
