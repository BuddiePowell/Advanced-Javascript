// Name: Buddie Powell
// Date: 3/08/2026
// course: Advanced JavaScript hybrid monday/wednesday 10:30am- 12:10pm

// constants for the username and country code for the geonames api
const USERNAME = "bpowell5";
const COUNTRYCODE = "US";
// function to initialize the event listener for the button click
const init = () => {
  let weatherButton = document.querySelector("#getWeather");
  weatherButton.addEventListener("click", getLocation);
};
// this function gets the location based on the postal code entered by the user and then calls the getWeather function with the latitude and longitude of that location
const getLocation = () => {
  let enteredpostalcode = document.querySelector("#zipcode").value;

  let url = "https://secure.geonames.org/postalCodeSearchJSON";

  let newParams = `?username=${USERNAME}&postalcode=${enteredpostalcode}&country=${COUNTRYCODE}`;

  // this creates a new XMLHttpRequest object to get the location data from the geonames api and then calls the getWeather function with the latitude and longitude of that location
  let xhr = new XMLHttpRequest();
  xhr.open("GET", url + newParams);
  xhr.onreadystatechange = () => {
    if (xhr.readyState === 4) {
      let data = JSON.parse(xhr.responseText);

      console.log(data);
      let lat = data.postalCodes[0].lat;
      let lng = data.postalCodes[0].lng;

      getWeather(lat, lng);
    }

    xhr.send(null);
  };
};
// this function gets the latitude and longitude from
// the getLocation function and then logs them to the console.
const getWeather = (lat, lng) => {
  console.log("Latitude: " + lat);
  console.log("Longitude: " + lng);
};
// loads the init function when the window loads to set up the event listener for the button click
window.onload = init;
