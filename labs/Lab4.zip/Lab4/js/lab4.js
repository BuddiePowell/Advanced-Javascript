const init = () => {
  // Setup dot notation event handlers for group 2 buttons
  const group2Buttons = document.querySelectorAll("#group2 button");
  group2Buttons.forEach((button) => {
    button.onclick = dotNotation;
  });

  // Setup addEventListener event handlers the group 3 buttons
  const group3Buttons = document.querySelectorAll("#group3 button");
  group3Buttons.forEach((button) => {
    button.addEventListener("click", w3c);
  });
};

const inline = (event) => console.log(event.value);

const dotNotation = (event) => console.log(event.target.value);

const w3c = (event) => console.log(event.target.value);

window.onload = init;
